from django.apps import AppConfig


class MoviesConfig(AppConfig):
    name = 'movies'
