from django.contrib import admin
from .models import Moviedata
# Register your models here.
admin.site.register(Moviedata)
