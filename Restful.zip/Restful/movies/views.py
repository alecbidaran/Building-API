from django.shortcuts import render
from rest_framework import viewsets
from .serializer import MovieSerializer
from .models import Moviedata

class MovieViewSet(viewsets.ModelViewSet):
    queryset = Moviedata.objects.all()
    serializer_class = MovieSerializer
# Create your views here.
class DramaViewSet(viewsets.ModelViewSet):
    queryset = Moviedata.objects.filter(typ='drama')
    serializer_class = MovieSerializer
